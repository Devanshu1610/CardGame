﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarGame
{
    class Program
    {
        public static void ExitCardGame()
        {
            System.Environment.Exit(1);
        }

        static void Main(string[] args)
        {
            string Option1 = string.Empty, Option2 = string.Empty;
            Deck deckObj = new Deck();
            Console.WriteLine("Welcome to CardGame!");
            Console.WriteLine("Enter 1 to Start \nEnter 0 to Quit ");
            try
            {
                Option1 = Console.ReadLine();
                switch (Option1.ToString())
                {
                    case "1":
                        deckObj.CreateDeck();
                        deckObj.Shuffle();

                        int promptNo = 52;

                        for (int i = 0; i < promptNo;)
                        {
                            Console.WriteLine("Enter:\np to play a card from deck\ns to shuffle cards\nr to restart\nn to get no. of cards in deck\n0 to quit the game");
                            Option2 = Console.ReadLine();
                            switch (Option2.ToLower())
                            {
                                case "p":
                                    Console.WriteLine("Your card is " + deckObj.PlayCard());
                                    i++;
                                    break;
                                case "s":
                                    deckObj.Shuffle();
                                    break;
                                case "r":
                                    deckObj.CreateDeck();
                                    promptNo = 52;
                                    i = 0;
                                    break;

                                case "n":
                                    Console.WriteLine("number of cards in deck " + deckObj.deck.Length);
                                    break;
                                case "0":
                                    ExitCardGame();
                                    break;
                                default:
                                    Console.WriteLine("Invalid option!");
                                    break;

                            }
                        }

                        break;
                    case "0":
                        ExitCardGame();
                        break;
                    default:
                        Console.WriteLine("Please enter a valid option!");
                        break;
                }

            }
            catch (Exception exp)
            {
                Console.WriteLine("Error Message: " + exp.Message);

            }
            

            }
    } 
}
