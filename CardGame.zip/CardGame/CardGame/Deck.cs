﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CarGame
{
    

   public class Deck
    {
        public Card[] deck;
        private int currentCard;
        private const int NUMBER_OF_CARDS = 52;
        private Random ranNum;
        

        public Deck()
        {

          
        }
        /// <summary>
        /// Create deck of 52 cards
        /// </summary>
        public void CreateDeck()
        {
            string[] faces = { "Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King" };
            string[] suits = { "Heart", "Clubs", "Daimonds", "Spades" };
            deck = new Card[NUMBER_OF_CARDS];
            ranNum = new Random();
            //fill the deck with cards
            for (int count = 0; count < deck.Length; count++)
            {
                deck[count] = new Card(faces[count % 13], suits[count / 13]);
            }
            Console.WriteLine("Deck is created!");

        }/// <summary>
        /// shuffle cards in a deck
        /// </summary>
        public void Shuffle()
        {
            try
            {
                currentCard = 0;
                for (int top = 0; top < deck.Length; top++)
                {

                    int second = ranNum.Next(deck.Length);
                    Card temp = deck[top];
                    deck[top] = deck[second];
                    deck[second] = temp;


                }
                Console.WriteLine("Cards are shuffled!");
            }
            catch (Exception)
            {
                throw new Exception("Error occured in shuffle");
            }
        }
        /// <summary>
        /// play a card from deck
        /// </summary>
        /// <returns></returns>
        public Card PlayCard()
        {
            if (deck.Length>0 )
            {
                try
                {
                    int indexOfCurrentCard = Array.IndexOf(deck, deck[currentCard]);
                    if (deck.Length > 1)
                        deck = deck.Where((val, idx) => idx != indexOfCurrentCard).ToArray();
                    return deck[currentCard];
                }
                catch (Exception)
                {
                    throw new Exception("Error occured in PlayCard ");
                }
              
                
            }
            else
                return null;

        }

        
    }
}
